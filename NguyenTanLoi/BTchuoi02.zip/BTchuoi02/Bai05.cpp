#include<iostream>
#include<string> 
#include<stdio.h>
using namespace std;
int main()
{
	char s[100],s2[10];
	string x[20];
	int n;
	gets(s);
	x[0]="khong";
	x[1]="mot";
	x[2]="hai";
	x[3]="ba";
	x[4]="bon";
	x[5]="nam";
	x[6]="sau";
	x[7]="bay";
	x[8]="tam";
	x[9]="chin";
	for(int i=0;i<strlen(s);i++){
		strncpy(s2,s+i,1);
		sscanf(s2, "%d", &n);
		cout<<x[n]<<" ";
	}
	cout<<endl;
return 0;
}

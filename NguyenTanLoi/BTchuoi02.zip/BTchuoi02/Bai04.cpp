#include<iostream>
#include<string>
using namespace std;
int main()
{
	char s[100],s2[100];
	int n,i;
	gets(s);
	s[0]=s[0]-32;
	for(int i=0;i<strlen(s);i++)
		if(s[i]==' '){
			if(s[i+1]>=97&&s[i+1]<=122)
        		 s[i+1]=s[i+1]-32;			
		}
	cout<<s<<endl;		
return 0;
}

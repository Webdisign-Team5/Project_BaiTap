#include<iostream>
#include<string>
using namespace std;
int main()
{
	char s[100],s2[100];
	gets(s);
	strcpy(s2,s);
	strupr(s2);
	cout<<s<<endl;
	cout<<s2<<endl;
	int d=0;
	for (int i=0;i<strlen(s);i++)
		if (s[i]!=s2[i]) d++;
	if(d>0)	cout<<"Chuoi co ky tu khong in hoa"<<endl;
		else cout<<"chuoi in hoa";
return 0;
}
#include<iostream>
#include<string>
using namespace std;
int main()
{
	char s[100],s2[100];
	int n,i;
	gets(s);
	cout<<s<<endl;
	cout<<"nhap so i: ";
	cin>>i;
	cout<<"nhap so n: ";
	cin>>n;
	s2[n-i]='\0';
	strncpy(s2,s+i,n-i);
	cout<<s2<<endl;
	
return 0;
}
